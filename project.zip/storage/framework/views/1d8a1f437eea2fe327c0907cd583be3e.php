<?php $__env->startSection('title', 'Add Student'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6">
  <a href="<?php echo e(route('principal.students.index')); ?>" class="text-xs text-gray-500 hover:text-navy">← All Students</a>
  <h1 class="text-2xl md:text-3xl font-extrabold text-navy mt-1">Add New Student</h1>
  <p class="text-sm text-gray-500">Next ADM will be <span class="font-mono font-bold text-navy"><?php echo e($nextAdm); ?></span> (auto-assigned)</p>
</div>

<?php if($errors->any()): ?>
  <div class="bg-red-50 border-l-4 border-red-600 p-4 rounded-lg mb-4">
    <ul class="text-sm text-red-700 list-disc list-inside">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($e); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<div class="bg-white rounded-2xl p-6 md:p-8 shadow max-w-3xl">
  <form method="POST" action="<?php echo e(route('principal.students.store')); ?>" class="grid grid-cols-1 md:grid-cols-2 gap-4">
    <?php echo csrf_field(); ?>

    <div class="md:col-span-2">
      <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">STUDENT NAME *</label>
      <input name="name" value="<?php echo e(old('name')); ?>" required class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
    </div>

    <div>
      <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">CLASS *</label>
      <select name="class" required class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
        <option value="">-- Select --</option>
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($c); ?>" <?php if(old('class') === $c): echo 'selected'; endif; ?>><?php echo e($c); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div>
      <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">STREAM</label>
      <select name="stream" class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
        <option value="">-- None --</option>
        <?php $__currentLoopData = $streams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($s); ?>" <?php if(old('stream') === $s): echo 'selected'; endif; ?>><?php echo e($s); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="md:col-span-2">
      <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">PARENT / GUARDIAN NAME *</label>
      <input name="parent_name" value="<?php echo e(old('parent_name')); ?>" required class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
    </div>

    <div>
      <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">PARENT PHONE *</label>
      <input name="parent_phone" value="<?php echo e(old('parent_phone')); ?>" required placeholder="07XXXXXXXX" class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
    </div>

    <div>
      <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">PARENT EMAIL</label>
      <input name="parent_email" type="email" value="<?php echo e(old('parent_email')); ?>" class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
    </div>

    <div class="md:col-span-2">
      <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">TOTAL FEE (KES) *</label>
      <input name="total_fee" type="number" min="0" step="100" value="<?php echo e(old('total_fee', 45000)); ?>" required class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
    </div>

    <div class="md:col-span-2 flex flex-col sm:flex-row gap-3">
      <button class="flex-1 min-h-[48px] rounded-xl bg-gold text-navy font-bold hover:scale-[1.02] transition">✅ Register Student</button>
      <a href="<?php echo e(route('principal.students.index')); ?>" class="flex-1 min-h-[48px] rounded-xl bg-gray-100 text-gray-700 font-semibold text-center leading-[48px] hover:bg-gray-200 transition">Cancel</a>
    </div>
  </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/principal/students/create.blade.php ENDPATH**/ ?>
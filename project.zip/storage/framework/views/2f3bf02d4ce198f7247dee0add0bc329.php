<?php $__env->startSection('title', 'All Payments'); ?>
<?php $__env->startSection('content'); ?>

<div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-6">
  <div>
    <h1 class="text-2xl md:text-3xl font-extrabold text-navy">All Payments</h1>
    <p class="text-sm text-gray-500 mt-1"><?php echo e($payments->total()); ?> records · Total KES <?php echo e(number_format($total, 0)); ?></p>
  </div>
</div>

<div class="bg-white rounded-2xl p-4 shadow mb-4">
  <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-2">
    <input name="q" value="<?php echo e($q); ?>" placeholder="Search name, ADM, txn, receipt" class="md:col-span-2 min-h-[42px] rounded-xl border-2 border-gray-200 px-4 text-sm focus:border-gold focus:outline-none">
    <select name="method" class="min-h-[42px] rounded-xl border-2 border-gray-200 px-4 text-sm">
      <option value="">All Methods</option>
      <option value="M-Pesa" <?php if($method==='M-Pesa'): echo 'selected'; endif; ?>>M-Pesa</option>
      <option value="Cash" <?php if($method==='Cash'): echo 'selected'; endif; ?>>Cash</option>
      <option value="Bank" <?php if($method==='Bank'): echo 'selected'; endif; ?>>Bank</option>
    </select>
    <button class="min-h-[42px] rounded-xl bg-navy text-white text-sm font-semibold">Apply</button>
  </form>
</div>

<div class="bg-white rounded-2xl shadow overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-xs md:text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500">
        <tr class="text-left">
          <th class="p-3">DATE</th>
          <th class="p-3">RECEIPT</th>
          <th class="p-3">STUDENT</th>
          <th class="p-3">METHOD</th>
          <th class="p-3 text-right">AMOUNT</th>
          <th class="p-3 text-right">PDF</th>
        </tr>
      </thead>
      <tbody class="divide-y">
        <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="hover:bg-gray-50">
            <td class="p-3 text-gray-500"><?php echo e($p->created_at->format('d M H:i')); ?></td>
            <td class="p-3 font-mono text-navy"><?php echo e($p->receipt_no); ?></td>
            <td class="p-3">
              <div class="font-semibold text-navy"><?php echo e($p->student->name ?? '—'); ?></div>
              <div class="text-xs text-gray-500"><?php echo e($p->student->adm_no ?? ''); ?></div>
            </td>
            <td class="p-3"><?php echo e($p->method); ?></td>
            <td class="p-3 text-right font-bold text-navy">KES <?php echo e(number_format($p->amount, 0)); ?></td>
            <td class="p-3 text-right"><a href="<?php echo e(URL::signedRoute('pay.receipt', ['payment' => $p->id])); ?>" class="text-navy hover:text-gold font-semibold">📄</a></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" class="p-12 text-center text-gray-400">No payments</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="mt-4"><?php echo e($payments->links()); ?></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bursar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/bursar/payments.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Marks Entry'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6">
  <a href="<?php echo e(route('dos.exams.index')); ?>" class="text-xs text-gray-500 hover:text-navy">← Exams</a>
  <h1 class="text-2xl md:text-3xl font-extrabold text-navy mt-1">Marks Entry</h1>
</div>

<?php if(session('success')): ?>
  <div class="bg-green-50 border-l-4 border-green-600 p-4 rounded-lg mb-4"><div class="font-bold text-green-700">✅ <?php echo e(session('success')); ?></div></div>
<?php endif; ?>
<?php if(session('error')): ?>
  <div class="bg-red-50 border-l-4 border-red-600 p-4 rounded-lg mb-4"><div class="font-bold text-red-700"><?php echo e(session('error')); ?></div></div>
<?php endif; ?>


<div class="bg-white rounded-2xl p-5 shadow mb-4">
  <form method="GET" action="<?php echo e(route('dos.marks')); ?>" class="grid grid-cols-1 md:grid-cols-3 gap-3">
    <select name="exam_id" required class="min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
      <option value="">-- Select Exam --</option>
      <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($e->id); ?>" <?php if($exam && $exam->id === $e->id): echo 'selected'; endif; ?>><?php echo e($e->name); ?> · <?php echo e($e->term); ?> <?php echo e($e->year); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <select name="class_id" required class="min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
      <option value="">-- Select Class --</option>
      <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($c->id); ?>" <?php if($class && $class->id === $c->id): echo 'selected'; endif; ?>><?php echo e($c->label()); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <button class="min-h-[48px] rounded-xl bg-navy text-white font-semibold hover:scale-[1.02] transition">🔍 Load</button>
  </form>
</div>

<?php if($exam && $class): ?>
  <div class="mb-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
    <div>
      <div class="text-lg font-bold text-navy"><?php echo e($exam->name); ?> · <?php echo e($class->label()); ?></div>
      <div class="text-xs text-gray-500"><?php echo e($students->count()); ?> students</div>
    </div>
    <div class="text-xs text-gray-500 bg-yellow-50 border-l-4 border-yellow-500 px-3 py-2 rounded">
      💡 Enter marks 0–100. Leave blank to skip a subject.
    </div>
  </div>

  <?php if($students->isEmpty()): ?>
    <div class="bg-white rounded-2xl p-12 text-center text-gray-400 shadow">No students in this class.</div>
  <?php else: ?>
    <form method="POST" action="<?php echo e(route('dos.marks.store')); ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="exam_id" value="<?php echo e($exam->id); ?>">
      <input type="hidden" name="class_id" value="<?php echo e($class->id); ?>">

      <div class="bg-white rounded-2xl shadow overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-xs">
            <thead class="bg-navy text-white sticky top-0">
              <tr>
                <th class="p-2 text-left sticky left-0 bg-navy z-10 min-w-[180px]">STUDENT</th>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <th class="p-2 text-center min-w-[80px]"><?php echo e(\Illuminate\Support\Str::limit($sub, 10)); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tr>
            </thead>
            <tbody class="divide-y">
              <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50">
                  <td class="p-2 sticky left-0 bg-white z-10 font-semibold text-navy">
                    <?php echo e($s->name); ?>

                    <div class="text-[10px] text-gray-500 font-mono"><?php echo e($s->adm_no); ?></div>
                  </td>
                  <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $existing = $existing[$s->id][$sub] ?? null;
                    ?>
                    <td class="p-1 text-center">
                      <input type="number" min="0" max="100"
                             name="marks[<?php echo e($s->id); ?>][<?php echo e($sub); ?>]"
                             value="<?php echo e($existing->marks ?? ''); ?>"
                             class="w-full max-w-[70px] h-9 rounded-lg border-2 border-gray-200 text-center text-xs focus:border-gold focus:outline-none">
                    </td>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="mt-4 flex gap-3 sticky bottom-4">
        <button class="flex-1 min-h-[52px] rounded-xl bg-gold text-navy font-bold shadow-2xl hover:scale-[1.02] transition">💾 Save All Marks</button>
      </div>
    </form>
  <?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dos', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/dos/exams/marks.blade.php ENDPATH**/ ?>
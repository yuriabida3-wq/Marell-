<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>

<div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-6">
  <div>
    <h1 class="text-2xl md:text-3xl font-extrabold text-navy">Users</h1>
    <p class="text-sm text-gray-500 mt-1"><?php echo e($users->total()); ?> staff members</p>
  </div>
  <a href="<?php echo e(route('principal.users.create')); ?>" class="px-4 py-2 rounded-xl bg-gold text-navy font-bold text-sm hover:scale-105 transition">+ Add User</a>
</div>

<?php if(session('success')): ?>
  <div class="bg-green-50 border-l-4 border-green-600 p-4 rounded-lg mb-4"><div class="font-bold text-green-700">✅ <?php echo e(session('success')); ?></div></div>
<?php endif; ?>
<?php if(session('error')): ?>
  <div class="bg-red-50 border-l-4 border-red-600 p-4 rounded-lg mb-4"><div class="font-bold text-red-700"><?php echo e(session('error')); ?></div></div>
<?php endif; ?>

<div class="bg-white rounded-2xl p-4 shadow mb-4">
  <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-3">
    <input name="q" value="<?php echo e($q); ?>" placeholder="🔍 Name, email, phone..."
           class="md:col-span-2 min-h-[42px] rounded-xl border-2 border-gray-200 px-4 text-sm focus:border-gold focus:outline-none">
    <select name="role" class="min-h-[42px] rounded-xl border-2 border-gray-200 px-4 text-sm focus:border-gold focus:outline-none">
      <option value="">All Roles</option>
      <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($r); ?>" <?php if($role === $r): echo 'selected'; endif; ?>><?php echo e(ucfirst($r)); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="md:col-span-3 min-h-[42px] rounded-xl bg-navy text-white font-semibold text-sm hover:scale-[1.02] transition">Apply</button>
  </form>
</div>

<div class="bg-white rounded-2xl shadow overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500">
        <tr class="text-left">
          <th class="p-3">NAME</th>
          <th class="p-3">EMAIL</th>
          <th class="p-3">PHONE</th>
          <th class="p-3">ROLE</th>
          <th class="p-3 text-center">STATUS</th>
          <th class="p-3 text-right">ACTION</th>
        </tr>
      </thead>
      <tbody class="divide-y">
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="hover:bg-gray-50">
            <td class="p-3 font-semibold text-navy"><?php echo e($u->name); ?></td>
            <td class="p-3 text-gray-600 text-xs"><?php echo e($u->email); ?></td>
            <td class="p-3 text-gray-600 font-mono text-xs"><?php echo e($u->phone ?: '—'); ?></td>
            <td class="p-3">
              <?php $__currentLoopData = $u->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="px-2 py-1 rounded-full text-xs font-bold bg-navy/10 text-navy"><?php echo e($r); ?></span>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td class="p-3 text-center">
              <?php if($u->active): ?>
                <span class="px-2 py-1 rounded-full text-xs font-bold bg-green-100 text-green-700">Active</span>
              <?php else: ?>
                <span class="px-2 py-1 rounded-full text-xs font-bold bg-red-100 text-red-700">Inactive</span>
              <?php endif; ?>
            </td>
            <td class="p-3 text-right whitespace-nowrap">
              <a href="<?php echo e(route('principal.users.edit', $u)); ?>" class="text-xs font-semibold text-navy hover:text-gold">Edit</a>
              <form method="POST" action="<?php echo e(route('principal.users.toggle', $u)); ?>" class="inline">
                <?php echo csrf_field(); ?>
                <button class="text-xs font-semibold <?php echo e($u->active ? 'text-red-600' : 'text-green-600'); ?> hover:underline ml-2">
                  <?php echo e($u->active ? 'Deactivate' : 'Activate'); ?>

                </button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" class="p-12 text-center text-gray-400 text-sm">No users</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="mt-4"><?php echo e($users->links()); ?></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/principal/users/index.blade.php ENDPATH**/ ?>
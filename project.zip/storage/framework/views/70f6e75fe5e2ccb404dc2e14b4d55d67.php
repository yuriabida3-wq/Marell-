<?php $__env->startSection('title', 'Report Cards'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6">
  <h1 class="text-2xl md:text-3xl font-extrabold text-navy">Report Cards</h1>
  <p class="text-sm text-gray-500 mt-1">Generate PDF report cards for an entire class in one click.</p>
</div>

<?php if(session('success')): ?>
  <div class="bg-green-50 border-l-4 border-green-600 p-4 rounded-lg mb-4"><div class="font-bold text-green-700">✅ <?php echo e(session('success')); ?></div></div>
<?php endif; ?>
<?php if(session('error')): ?>
  <div class="bg-red-50 border-l-4 border-red-600 p-4 rounded-lg mb-4"><div class="font-bold text-red-700"><?php echo e(session('error')); ?></div></div>
<?php endif; ?>

<div class="bg-white rounded-2xl p-6 md:p-8 shadow max-w-2xl">
  <h2 class="font-extrabold text-navy mb-4">📄 Bulk Generate</h2>

  <?php if($exams->isEmpty() || $classes->isEmpty()): ?>
    <div class="bg-yellow-50 border-l-4 border-yellow-500 p-3 text-sm rounded">
      ⚠️ You need at least one exam and one class first.
    </div>
  <?php else: ?>
    <form method="POST" action="<?php echo e(route('dos.report-cards.bulk')); ?>" class="space-y-4">
      <?php echo csrf_field(); ?>

      <div>
        <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">EXAM *</label>
        <select name="exam_id" required class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
          <option value="">-- Select Exam --</option>
          <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($e->id); ?>"><?php echo e($e->name); ?> · <?php echo e($e->term); ?> <?php echo e($e->year); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      <div>
        <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">CLASS *</label>
        <select name="class_id" required class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
          <option value="">-- Select Class --</option>
          <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->id); ?>"><?php echo e($c->label()); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      <button class="w-full min-h-[48px] rounded-xl bg-gold text-navy font-bold hover:scale-[1.02] transition">
        📥 Generate PDF (one page per student)
      </button>

      <p class="text-xs text-gray-500">
        💡 Students without marks for the selected exam will be skipped.
      </p>
    </form>
  <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dos', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/dos/report-cards/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Enter Marks'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6">
  <h1 class="text-2xl md:text-3xl font-extrabold text-navy">Enter Marks</h1>
  <p class="text-sm text-gray-500 mt-1">Pick exam, class, subject — enter marks for your students.</p>
</div>

<?php if(session('success')): ?>
  <div class="bg-green-50 border-l-4 border-green-600 p-4 rounded-lg mb-4"><div class="font-bold text-green-700">✅ <?php echo e(session('success')); ?></div></div>
<?php endif; ?>
<?php if(session('error')): ?>
  <div class="bg-red-50 border-l-4 border-red-600 p-4 rounded-lg mb-4"><div class="font-bold text-red-700"><?php echo e(session('error')); ?></div></div>
<?php endif; ?>

<?php if($exams->isEmpty()): ?>
  <div class="bg-yellow-50 border-l-4 border-yellow-500 p-4 text-sm rounded">
    ⚠️ No exams are open for marks entry. Ask the DOS to open one.
  </div>
<?php endif; ?>

<div class="bg-white rounded-2xl p-5 shadow mb-4">
  <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-3">
    <select name="exam_id" required class="min-h-[48px] rounded-xl border-2 border-gray-200 px-4 text-sm">
      <option value="">-- Exam --</option>
      <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($e->id); ?>" <?php if($exam && $exam->id===$e->id): echo 'selected'; endif; ?>><?php echo e($e->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <select name="class" required class="min-h-[48px] rounded-xl border-2 border-gray-200 px-4 text-sm">
      <option value="">-- Class --</option>
      <?php $__currentLoopData = $classKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($ck->class); ?>" <?php if(request('class')===$ck->class): echo 'selected'; endif; ?>><?php echo e($ck->class); ?> <?php echo e($ck->stream); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="hidden" name="stream" value="<?php echo e(request('stream')); ?>">

    <select name="subject" required class="min-h-[48px] rounded-xl border-2 border-gray-200 px-4 text-sm">
      <option value="">-- Subject --</option>
      <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($sub); ?>" <?php if(request('subject')===$sub): echo 'selected'; endif; ?>><?php echo e($sub); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <button class="min-h-[48px] rounded-xl bg-navy text-white font-semibold text-sm">🔍 Load</button>
  </form>
</div>

<?php if($exam && $classKey && $students->count()): ?>
  <form method="POST" action="<?php echo e(route('teacher.marks.store')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="exam_id" value="<?php echo e($exam->id); ?>">
    <input type="hidden" name="class" value="<?php echo e($classKey['class']); ?>">
    <input type="hidden" name="stream" value="<?php echo e($classKey['stream']); ?>">
    <input type="hidden" name="subject" value="<?php echo e(request('subject')); ?>">

    <div class="bg-white rounded-2xl shadow overflow-hidden">
      <div class="p-4 bg-gray-50 border-b">
        <div class="font-bold text-navy text-sm"><?php echo e($exam->name); ?> · <?php echo e(request('subject')); ?> · <?php echo e($classKey['class']); ?> <?php echo e($classKey['stream']); ?></div>
        <div class="text-xs text-gray-500"><?php echo e($students->count()); ?> students · Grades auto-computed</div>
      </div>
      <table class="w-full text-sm">
        <thead class="bg-navy text-white text-xs">
          <tr><th class="p-2 text-left">STUDENT</th><th class="p-2 text-center w-32">MARKS</th><th class="p-2 text-center w-24">GRADE</th></tr>
        </thead>
        <tbody class="divide-y">
          <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $exist = $existing[$s->id] ?? null; ?>
            <tr>
              <td class="p-2">
                <div class="font-semibold text-navy text-sm"><?php echo e($s->name); ?></div>
                <div class="text-xs text-gray-500 font-mono"><?php echo e($s->adm_no); ?></div>
              </td>
              <td class="p-2 text-center">
                <input type="number" name="marks[<?php echo e($s->id); ?>]" min="0" max="100"
                       value="<?php echo e($exist->marks ?? ''); ?>"
                       class="w-24 h-10 rounded-lg border-2 border-gray-200 text-center text-sm focus:border-gold focus:outline-none markInput"
                       oninput="updateGrade(this)">
              </td>
              <td class="p-2 text-center font-bold gradeCell text-gray-400"><?php echo e($exist->grade ?? '—'); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>

    <button class="mt-4 w-full min-h-[52px] rounded-xl bg-gold text-navy font-bold shadow-lg">💾 Save Marks</button>
  </form>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script>
  function gradeFromMarks(m) {
    if (m >= 80) return 'A'; if (m >= 75) return 'A-';
    if (m >= 70) return 'B+'; if (m >= 65) return 'B'; if (m >= 60) return 'B-';
    if (m >= 55) return 'C+'; if (m >= 50) return 'C'; if (m >= 45) return 'C-';
    if (m >= 40) return 'D+'; if (m >= 35) return 'D';
    return 'E';
  }
  function updateGrade(input) {
    const cell = input.closest('tr').querySelector('.gradeCell');
    const val  = parseInt(input.value);
    if (isNaN(val)) { cell.textContent = '—'; cell.className = 'p-2 text-center font-bold gradeCell text-gray-400'; return; }
    const g = gradeFromMarks(val);
    cell.textContent = g;
    cell.className = 'p-2 text-center font-bold gradeCell ' +
      (['A','A-'].includes(g) ? 'text-green-600' :
       ['B+','B','B-'].includes(g) ? 'text-blue-600' :
       ['C+','C','C-'].includes(g) ? 'text-yellow-600' : 'text-red-600');
  }
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/teacher/marks.blade.php ENDPATH**/ ?>
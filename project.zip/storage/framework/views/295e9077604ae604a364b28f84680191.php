<?php $__env->startSection('title', $student->name); ?>
<?php $__env->startSection('content'); ?>

<div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-6">
  <div>
    <a href="<?php echo e(route('principal.students.index')); ?>" class="text-xs text-gray-500 hover:text-navy">← All Students</a>
    <h1 class="text-2xl md:text-3xl font-extrabold text-navy mt-1"><?php echo e($student->name); ?></h1>
    <p class="text-sm text-gray-500"><?php echo e($student->adm_no); ?> · <?php echo e($student->class); ?> <?php echo e($student->stream); ?></p>
  </div>
  <div class="flex flex-wrap gap-2">
    <a href="<?php echo e(route('principal.students.edit', $student)); ?>" class="px-4 py-2 rounded-xl bg-navy text-white font-semibold text-sm hover:scale-105 transition">✏️ Edit</a>
    <form method="POST" action="<?php echo e(route('principal.students.toggle', $student)); ?>">
      <?php echo csrf_field(); ?>
      <button class="px-4 py-2 rounded-xl <?php echo e($student->status === 'active' ? 'bg-red-600' : 'bg-green-600'); ?> text-white font-semibold text-sm hover:scale-105 transition">
        <?php echo e($student->status === 'active' ? '🚫 Suspend' : '✅ Activate'); ?>

      </button>
    </form>
  </div>
</div>


<div class="grid grid-cols-3 gap-4 mb-6">
  <div class="bg-white rounded-2xl p-5 shadow">
    <div class="text-xs text-gray-500 tracking-widest font-semibold">TOTAL FEE</div>
    <div class="text-2xl font-extrabold text-navy mt-1">KES <?php echo e(number_format($student->total_fee, 0)); ?></div>
  </div>
  <div class="bg-green-50 rounded-2xl p-5 shadow">
    <div class="text-xs text-gray-500 tracking-widest font-semibold">PAID</div>
    <div class="text-2xl font-extrabold text-green-700 mt-1">KES <?php echo e(number_format($student->paid_amount, 0)); ?></div>
  </div>
  <div class="bg-red-50 rounded-2xl p-5 shadow">
    <div class="text-xs text-gray-500 tracking-widest font-semibold">BALANCE</div>
    <div class="text-2xl font-extrabold text-red-600 mt-1">KES <?php echo e(number_format($student->balance, 0)); ?></div>
  </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 gap-6">

  
  <div class="bg-white rounded-2xl p-6 shadow">
    <h2 class="font-extrabold text-navy mb-4">👤 Profile</h2>
    <table class="w-full text-sm">
      <tr class="border-b"><td class="py-2 text-gray-500">ADM No</td><td class="py-2 font-semibold text-navy text-right"><?php echo e($student->adm_no); ?></td></tr>
      <tr class="border-b"><td class="py-2 text-gray-500">Class</td><td class="py-2 text-right"><?php echo e($student->class); ?> <?php echo e($student->stream); ?></td></tr>
      <tr class="border-b"><td class="py-2 text-gray-500">Parent</td><td class="py-2 text-right"><?php echo e($student->parent_name); ?></td></tr>
      <tr class="border-b"><td class="py-2 text-gray-500">Phone</td><td class="py-2 text-right font-mono text-xs"><?php echo e($student->parent_phone); ?></td></tr>
      <tr class="border-b"><td class="py-2 text-gray-500">Email</td><td class="py-2 text-right"><?php echo e($student->parent_email ?: '—'); ?></td></tr>
      <tr><td class="py-2 text-gray-500">Status</td><td class="py-2 text-right font-semibold"><?php echo e(ucfirst($student->status)); ?></td></tr>
    </table>
  </div>

  
  <div class="bg-white rounded-2xl p-6 shadow">
    <div class="flex items-center justify-between mb-4">
      <h2 class="font-extrabold text-navy">📊 Results</h2>
      <span class="text-xs text-gray-500"><?php echo e($results->count()); ?> subjects</span>
    </div>
    <?php if($results->count()): ?>
      <table class="w-full text-sm">
        <thead class="text-xs text-gray-500">
          <tr><th class="text-left py-1">Subject</th><th class="text-center">Marks</th><th class="text-center">Grade</th></tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-t">
              <td class="py-2"><?php echo e($r->subject); ?></td>
              <td class="py-2 text-center font-bold"><?php echo e($r->marks); ?></td>
              <td class="py-2 text-center font-bold text-navy"><?php echo e($r->grade); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    <?php else: ?>
      <p class="text-sm text-gray-400 text-center py-6">No results yet</p>
    <?php endif; ?>
  </div>
</div>


<div class="bg-white rounded-2xl shadow mt-6 overflow-hidden">
  <div class="p-5 border-b flex items-center justify-between">
    <h2 class="font-extrabold text-navy">💳 Payment History</h2>
    <span class="text-xs text-gray-500"><?php echo e($payments->count()); ?> records</span>
  </div>
  <div class="overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500">
        <tr class="text-left">
          <th class="p-3">DATE</th>
          <th class="p-3">METHOD</th>
          <th class="p-3">TXN</th>
          <th class="p-3 text-right">AMOUNT</th>
          <th class="p-3 text-center">STATUS</th>
          <th class="p-3 text-right">RECEIPT</th>
        </tr>
      </thead>
      <tbody class="divide-y">
        <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="p-3 text-gray-500"><?php echo e($p->created_at->format('d M Y H:i')); ?></td>
            <td class="p-3"><?php echo e($p->method); ?></td>
            <td class="p-3 font-mono text-xs"><?php echo e($p->transaction_code ?: '—'); ?></td>
            <td class="p-3 text-right font-bold text-navy">KES <?php echo e(number_format($p->amount, 0)); ?></td>
            <td class="p-3 text-center">
              <span class="px-2 py-1 rounded-full text-xs font-bold
                <?php if($p->status==='completed'): ?> bg-green-100 text-green-700
                <?php elseif($p->status==='pending'): ?> bg-yellow-100 text-yellow-700
                <?php else: ?> bg-red-100 text-red-700 <?php endif; ?>"><?php echo e(ucfirst($p->status)); ?></span>
            </td>
            <td class="p-3 text-right">
              <?php if($p->status === 'completed'): ?>
                <a href="<?php echo e(URL::signedRoute('pay.receipt', ['payment' => $p->id])); ?>" class="text-xs font-semibold text-navy hover:text-gold">📄 PDF</a>
              <?php else: ?>
                —
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" class="p-8 text-center text-gray-400 text-sm">No payments yet</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/principal/students/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Fee Balances'); ?>
<?php $__env->startSection('content'); ?>

<div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-6">
  <div>
    <h1 class="text-2xl md:text-3xl font-extrabold text-navy">Fee Balances</h1>
    <p class="text-sm text-gray-500 mt-1">Total owed: <span class="font-bold text-red-600">KES <?php echo e(number_format($totalOwed, 0)); ?></span></p>
  </div>
  <a href="<?php echo e(route('bursar.balances.export')); ?>?<?php echo e(http_build_query(request()->only(['class','defaulters']))); ?>"
     class="px-4 py-2 rounded-xl bg-green-600 text-white font-semibold text-sm">📊 Export CSV</a>
</div>

<div class="bg-white rounded-2xl p-4 shadow mb-4">
  <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-2">
    <select name="class" class="min-h-[42px] rounded-xl border-2 border-gray-200 px-4 text-sm">
      <option value="">All Classes</option>
      <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($c); ?>" <?php if($class===$c): echo 'selected'; endif; ?>><?php echo e($c); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="defaulters" value="1" <?php if($onlyDefaulters): echo 'checked'; endif; ?> class="w-5 h-5"> Only with balance</label>
    <button class="min-h-[42px] rounded-xl bg-navy text-white text-sm font-semibold">Apply</button>
  </form>
</div>

<div class="bg-white rounded-2xl shadow overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-xs md:text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500">
        <tr class="text-left">
          <th class="p-3">ADM</th>
          <th class="p-3">NAME</th>
          <th class="p-3">CLASS</th>
          <th class="p-3 text-right">PAID</th>
          <th class="p-3 text-right">BALANCE</th>
          <th class="p-3 text-right">ACTION</th>
        </tr>
      </thead>
      <tbody class="divide-y">
        <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="hover:bg-gray-50">
            <td class="p-3 font-mono text-navy text-xs"><?php echo e($s->adm_no); ?></td>
            <td class="p-3 font-semibold text-navy"><?php echo e($s->name); ?></td>
            <td class="p-3 text-gray-600"><?php echo e($s->class); ?></td>
            <td class="p-3 text-right text-green-700">KES <?php echo e(number_format($s->paid_amount, 0)); ?></td>
            <td class="p-3 text-right font-bold <?php echo e($s->balance > 0 ? 'text-red-600' : 'text-green-600'); ?>">KES <?php echo e(number_format($s->balance, 0)); ?></td>
            <td class="p-3 text-right"><a href="<?php echo e(route('bursar.students')); ?>?adm=<?php echo e($s->adm_no); ?>" class="text-navy hover:text-gold font-semibold text-xs">Open</a></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" class="p-12 text-center text-gray-400">No students</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="mt-4"><?php echo e($students->links()); ?></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bursar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/bursar/balances.blade.php ENDPATH**/ ?>
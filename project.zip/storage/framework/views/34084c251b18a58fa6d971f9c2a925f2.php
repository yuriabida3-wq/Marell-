<?php $__env->startSection('title', $admission->student_name); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-6"><a href="<?php echo e(route('principal.admissions.index')); ?>" class="text-xs text-gray-500">← Applications</a><h1 class="text-2xl md:text-3xl font-extrabold text-navy mt-1"><?php echo e($admission->student_name); ?></h1></div>
<?php if(session('success')): ?><div class="bg-green-50 border-l-4 border-green-600 p-4 rounded-lg mb-4"><div class="font-bold text-green-700">✅ <?php echo e(session('success')); ?></div></div><?php endif; ?>
<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
  <div class="md:col-span-2 bg-white rounded-2xl p-6 shadow">
    <h2 class="font-extrabold text-navy mb-4">Application Details</h2>
    <table class="w-full text-sm">
      <tr class="border-b"><td class="py-2 text-gray-500">Student</td><td class="py-2 font-semibold text-navy text-right"><?php echo e($admission->student_name); ?></td></tr>
      <tr class="border-b"><td class="py-2 text-gray-500">DOB</td><td class="py-2 text-right"><?php echo e($admission->dob ? $admission->dob->format('d M Y') : '—'); ?></td></tr>
      <tr class="border-b"><td class="py-2 text-gray-500">Class Applying</td><td class="py-2 text-right"><?php echo e($admission->class_applying); ?></td></tr>
      <tr class="border-b"><td class="py-2 text-gray-500">Parent</td><td class="py-2 text-right"><?php echo e($admission->parent_name); ?></td></tr>
      <tr class="border-b"><td class="py-2 text-gray-500">Phone</td><td class="py-2 text-right font-mono"><?php echo e($admission->parent_phone); ?></td></tr>
      <tr class="border-b"><td class="py-2 text-gray-500">Email</td><td class="py-2 text-right"><?php echo e($admission->parent_email ?: '—'); ?></td></tr>
      <tr><td class="py-2 text-gray-500 align-top">Message</td><td class="py-2 text-right"><?php echo e($admission->message ?: '—'); ?></td></tr>
    </table>
    <div class="mt-6 flex flex-wrap gap-2">
      <a href="tel:<?php echo e($admission->parent_phone); ?>" class="px-4 py-2 rounded-xl bg-navy text-white text-sm font-semibold">📞 Call</a>
      <a href="https://wa.me/<?php echo e(preg_replace('/\D/','',$admission->parent_phone)); ?>" target="_blank" class="px-4 py-2 rounded-xl bg-green-600 text-white text-sm font-semibold">💬 WhatsApp</a>
      <a href="sms:<?php echo e($admission->parent_phone); ?>" class="px-4 py-2 rounded-xl bg-gray-200 text-navy text-sm font-semibold">📱 SMS</a>
    </div>
  </div>
  <div class="bg-white rounded-2xl p-6 shadow h-fit">
    <h2 class="font-extrabold text-navy mb-4">Status</h2>
    <form method="POST" action="<?php echo e(route('principal.admissions.status', $admission)); ?>" class="space-y-3">
      <?php echo csrf_field(); ?>
      <select name="status" class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4">
        <?php $__currentLoopData = ['new','contacted','admitted','rejected']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($s); ?>" <?php if($admission->status === $s): echo 'selected'; endif; ?>><?php echo e(ucfirst($s)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <button class="w-full min-h-[48px] rounded-xl bg-gold text-navy font-bold">Update Status</button>
    </form>
    <form method="POST" action="<?php echo e(route('principal.admissions.destroy', $admission)); ?>" class="mt-3" onsubmit="return confirm('Delete this application?')">
      <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
      <button class="w-full min-h-[42px] rounded-xl bg-red-50 text-red-600 text-sm font-semibold">Delete</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/principal/admissions/show.blade.php ENDPATH**/ ?>
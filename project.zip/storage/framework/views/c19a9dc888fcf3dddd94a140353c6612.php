<?php $__env->startSection('title', 'My Classes'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6">
  <h1 class="text-2xl md:text-3xl font-extrabold text-navy">My Classes</h1>
  <p class="text-sm text-gray-500 mt-1">Classes you teach, with student lists.</p>
</div>

<?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <div class="bg-white rounded-2xl p-5 shadow mb-4">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-2 mb-4">
      <div>
        <h2 class="font-extrabold text-navy text-lg"><?php echo e($c['class']); ?> <?php echo e($c['stream']); ?></h2>
        <div class="text-xs text-gray-500"><?php echo e($c['students']->count()); ?> students · Subjects: <?php echo e($c['subjects']->implode(', ')); ?></div>
      </div>
      <a href="<?php echo e(route('teacher.classListPdf')); ?>?class=<?php echo e(urlencode($c['class'])); ?>&stream=<?php echo e(urlencode($c['stream'])); ?>"
         class="px-4 py-2 rounded-xl bg-green-600 text-white text-xs font-semibold hover:scale-105 transition">📄 Class List PDF</a>
    </div>

    <div class="overflow-x-auto">
      <table class="w-full text-xs md:text-sm">
        <thead class="bg-gray-50 text-xs text-gray-500">
          <tr class="text-left">
            <th class="p-2">#</th>
            <th class="p-2">ADM</th>
            <th class="p-2">NAME</th>
            <th class="p-2">PARENT</th>
            <th class="p-2 text-right">BALANCE</th>
          </tr>
        </thead>
        <tbody class="divide-y">
          <?php $__currentLoopData = $c['students']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td class="p-2 text-gray-500"><?php echo e($i+1); ?></td>
              <td class="p-2 font-mono text-navy"><?php echo e($s->adm_no); ?></td>
              <td class="p-2 font-semibold text-navy"><?php echo e($s->name); ?></td>
              <td class="p-2 text-gray-600"><?php echo e($s->parent_name); ?></td>
              <td class="p-2 text-right <?php echo e($s->balance > 0 ? 'text-red-600' : 'text-green-600'); ?> font-bold">KES <?php echo e(number_format($s->balance, 0)); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <div class="bg-white rounded-2xl p-12 text-center text-gray-400 shadow">
    <div class="text-4xl mb-2">🎓</div>
    No classes assigned. Wait for DOS to assign you timetable slots.
  </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/teacher/classes.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'My Timetable'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
  <div>
    <h1 class="text-2xl md:text-3xl font-extrabold text-navy">My Timetable</h1>
    <p class="text-sm text-gray-500 mt-1">Your weekly schedule</p>
  </div>
  <button onclick="window.print()" class="px-4 py-2 rounded-xl bg-green-600 text-white font-semibold text-sm">📄 Print</button>
</div>

<div class="bg-white rounded-2xl shadow overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-xs">
      <thead class="bg-navy text-white">
        <tr>
          <th class="p-2 text-left w-16">PERIOD</th>
          <?php $__currentLoopData = ['Mon','Tue','Wed','Thu','Fri']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th class="p-2 text-center"><?php echo e($d); ?></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
      </thead>
      <tbody class="divide-y">
        <?php for($p = 1; $p <= 8; $p++): ?>
          <tr class="<?php echo e($p % 2 ? 'bg-white' : 'bg-gray-50'); ?>">
            <td class="p-2 font-bold text-navy">P<?php echo e($p); ?></td>
            <?php $__currentLoopData = ['Mon','Tue','Wed','Thu','Fri']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $slot = $grid[$d][$p] ?? null; ?>
              <td class="p-1.5 text-center align-top">
                <?php if($slot): ?>
                  <div class="rounded-lg bg-gold/10 border border-gold/40 p-1.5">
                    <div class="font-bold text-navy text-[11px]"><?php echo e($slot->subject); ?></div>
                    <div class="text-[9px] text-gray-600"><?php echo e($slot->class); ?> <?php echo e($slot->stream); ?></div>
                  </div>
                <?php else: ?>
                  <span class="text-gray-300">—</span>
                <?php endif; ?>
              </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
        <?php endfor; ?>
      </tbody>
    </table>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/teacher/timetable.blade.php ENDPATH**/ ?>
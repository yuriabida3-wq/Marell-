<?php $__env->startSection('title', 'Daily Report'); ?>
<?php $__env->startSection('content'); ?>

<div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-6">
  <div>
    <h1 class="text-2xl md:text-3xl font-extrabold text-navy">Daily Collection</h1>
    <p class="text-sm text-gray-500"><?php echo e(\Carbon\Carbon::parse($date)->format('l, d M Y')); ?></p>
  </div>
  <form method="GET" class="flex gap-2">
    <input type="date" name="date" value="<?php echo e($date); ?>" class="min-h-[42px] rounded-xl border-2 border-gray-200 px-3 text-sm">
    <button class="px-4 rounded-xl bg-navy text-white text-sm font-semibold">Go</button>
  </form>
</div>

<div class="bg-gradient-to-br from-navy to-[#082f6f] rounded-2xl p-6 text-white shadow-lg mb-4">
  <div class="text-[10px] tracking-widest font-bold text-gold">TOTAL COLLECTION</div>
  <div class="text-3xl md:text-4xl font-extrabold mt-2">KES <?php echo e(number_format($total, 0)); ?></div>
  <div class="text-xs opacity-70 mt-1"><?php echo e($payments->count()); ?> transactions</div>

  <?php if($byMethod->count()): ?>
    <div class="mt-4 pt-4 border-t border-white/20 grid grid-cols-3 gap-2 text-center">
      <?php $__currentLoopData = $byMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m => $amt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
          <div class="text-[10px] opacity-70"><?php echo e($m); ?></div>
          <div class="font-bold text-sm">KES <?php echo e(number_format($amt, 0)); ?></div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php endif; ?>
</div>

<div class="bg-white rounded-2xl shadow overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-xs md:text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500">
        <tr class="text-left">
          <th class="p-3">TIME</th>
          <th class="p-3">RECEIPT</th>
          <th class="p-3">STUDENT</th>
          <th class="p-3">METHOD</th>
          <th class="p-3 text-right">AMOUNT</th>
        </tr>
      </thead>
      <tbody class="divide-y">
        <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="p-3 text-gray-500"><?php echo e($p->created_at->format('H:i')); ?></td>
            <td class="p-3 font-mono text-navy"><?php echo e($p->receipt_no); ?></td>
            <td class="p-3"><?php echo e($p->student->name ?? '—'); ?></td>
            <td class="p-3"><?php echo e($p->method); ?></td>
            <td class="p-3 text-right font-bold text-navy">KES <?php echo e(number_format($p->amount, 0)); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="5" class="p-12 text-center text-gray-400">No collection on this date</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bursar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/bursar/daily.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6">
  <h1 class="text-2xl md:text-3xl font-extrabold text-navy">Good <?php echo e(now()->hour < 12 ? 'morning' : (now()->hour < 17 ? 'afternoon' : 'evening')); ?>, <?php echo e(explode(' ', auth()->user()->name)[0]); ?></h1>
  <p class="text-sm text-gray-500 mt-1">Today is <?php echo e(now()->format('l, d M Y')); ?></p>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-4">

  
  <div class="bg-white rounded-2xl p-5 shadow">
    <h2 class="font-extrabold text-navy mb-4">📅 Today's Classes (<?php echo e($today); ?>)</h2>
    <?php if($todaySlots->count()): ?>
      <div class="space-y-2">
        <?php $__currentLoopData = $todaySlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="p-3 rounded-xl bg-gray-50 border-l-4 border-gold">
            <div class="flex justify-between items-center">
              <div>
                <div class="font-bold text-navy text-sm">P<?php echo e($s->period); ?> · <?php echo e($s->subject); ?></div>
                <div class="text-xs text-gray-500"><?php echo e($s->class); ?> <?php echo e($s->stream); ?> · <?php echo e($s->start_time); ?>–<?php echo e($s->end_time); ?></div>
              </div>
              <div class="text-xs text-gray-400"><?php echo e($s->day); ?></div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php else: ?>
      <div class="text-center py-8 text-gray-400 text-sm">
        <div class="text-3xl mb-2">☕</div>
        No classes today.
      </div>
    <?php endif; ?>
  </div>

  
  <div class="bg-white rounded-2xl p-5 shadow">
    <div class="flex items-center justify-between mb-4">
      <h2 class="font-extrabold text-navy">🎓 My Classes</h2>
      <a href="/teacher/classes" class="text-xs text-navy hover:text-gold font-semibold">View all →</a>
    </div>
    <?php if($myClasses->count()): ?>
      <div class="space-y-2">
        <?php $__currentLoopData = $myClasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="flex items-center justify-between p-3 rounded-xl bg-gray-50">
            <div class="font-semibold text-navy text-sm"><?php echo e($c['class']); ?> <?php echo e($c['stream']); ?></div>
            <div class="text-xs text-gray-500"><?php echo e($c['count']); ?> students</div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php else: ?>
      <div class="text-center py-8 text-gray-400 text-sm">
        <div class="text-3xl mb-2">👨‍🏫</div>
        No classes assigned yet.
      </div>
    <?php endif; ?>
  </div>
</div>

<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
  <a href="/teacher/timetable" class="bg-white rounded-2xl p-5 shadow hover:shadow-lg transition text-center">
    <div class="text-3xl mb-2">📅</div>
    <div class="font-bold text-navy text-sm">My Timetable</div>
  </a>
  <a href="/teacher/marks" class="bg-white rounded-2xl p-5 shadow hover:shadow-lg transition text-center">
    <div class="text-3xl mb-2">✍️</div>
    <div class="font-bold text-navy text-sm">Enter Marks</div>
  </a>
  <a href="/teacher/classes" class="bg-white rounded-2xl p-5 shadow hover:shadow-lg transition text-center">
    <div class="text-3xl mb-2">🎓</div>
    <div class="font-bold text-navy text-sm">Class Lists</div>
  </a>
  <a href="/teacher/homework" class="bg-white rounded-2xl p-5 shadow hover:shadow-lg transition text-center">
    <div class="text-3xl mb-2">📚</div>
    <div class="font-bold text-navy text-sm">Homework</div>
  </a>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/teacher/dashboard.blade.php ENDPATH**/ ?>
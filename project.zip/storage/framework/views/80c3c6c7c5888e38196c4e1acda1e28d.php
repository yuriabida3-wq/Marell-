<?php $__env->startSection('title', 'Timetable'); ?>
<?php $__env->startSection('content'); ?>
<section class="bg-navy text-white py-16 md:py-20">
  <div class="max-w-7xl mx-auto px-4 text-center" data-aos="fade-up">
    <div class="text-gold font-bold tracking-widest text-sm">TIMETABLE</div>
    <h1 class="text-3xl md:text-5xl font-extrabold mt-2">Class Timetables</h1>
  </div>
</section>
<section class="max-w-7xl mx-auto px-4 py-12">
  <div class="card p-4 mb-6">
    <form method="GET" class="flex flex-col sm:flex-row gap-3">
      <select name="class_id" required class="flex-1 min-h-[48px] rounded-xl border-2 border-gray-200 px-4">
        <option value="">-- Select Class --</option>
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($c->id); ?>" <?php if($class && $class->id === $c->id): echo 'selected'; endif; ?>><?php echo e($c->label()); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <button class="btn btn-gold">View Timetable</button>
    </form>
  </div>

  <?php if($class && count($grid)): ?>
    <div class="card overflow-hidden">
      <div class="p-4 bg-navy text-white font-bold"><?php echo e($class->label()); ?></div>
      <div class="overflow-x-auto">
        <table class="w-full text-xs">
          <thead class="bg-gray-50"><tr><th class="p-2 text-left">PERIOD</th><?php $__currentLoopData = ['Mon','Tue','Wed','Thu','Fri']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th class="p-2"><?php echo e($d); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr></thead>
          <tbody class="divide-y">
            <?php for($p = 1; $p <= 8; $p++): ?>
              <tr><td class="p-2 font-bold text-navy">P<?php echo e($p); ?></td>
                <?php $__currentLoopData = ['Mon','Tue','Wed','Thu','Fri']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $s = $grid[$d][$p] ?? null; ?>
                  <td class="p-1.5 text-center"><?php if($s): ?><div class="rounded bg-gold/10 border border-gold/40 p-1.5"><div class="font-bold text-navy text-[11px]"><?php echo e($s->subject); ?></div><div class="text-[9px] text-gray-600"><?php echo e($s->teacher->name ?? '—'); ?></div></div><?php else: ?><span class="text-gray-300">—</span><?php endif; ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tr>
            <?php endfor; ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/public/timetable.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Homework'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6">
  <h1 class="text-2xl md:text-3xl font-extrabold text-navy">Homework</h1>
  <p class="text-sm text-gray-500 mt-1">Post assignments — parents get notified via SMS.</p>
</div>

<?php if(session('success')): ?>
  <div class="bg-green-50 border-l-4 border-green-600 p-4 rounded-lg mb-4"><div class="font-bold text-green-700">✅ <?php echo e(session('success')); ?></div></div>
<?php endif; ?>
<?php if($errors->any()): ?>
  <div class="bg-red-50 border-l-4 border-red-600 p-4 rounded-lg mb-4"><ul class="text-sm text-red-700 list-disc list-inside"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($e); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
<?php endif; ?>

<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
  
  <div class="bg-white rounded-2xl p-6 shadow">
    <h2 class="font-extrabold text-navy mb-4">➕ Post Homework</h2>
    <form method="POST" action="<?php echo e(route('teacher.homework.store')); ?>" class="space-y-3">
      <?php echo csrf_field(); ?>
      <div>
        <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">CLASS *</label>
        <select name="class" required class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
          <option value="">-- Select --</option>
          <?php $__currentLoopData = $classKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($ck->class); ?>"><?php echo e($ck->class); ?> <?php echo e($ck->stream); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <input type="hidden" name="stream" value="">
      <div>
        <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">SUBJECT *</label>
        <input name="subject" required class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
      </div>
      <div>
        <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">TITLE *</label>
        <input name="title" required maxlength="180" class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
      </div>
      <div>
        <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">DESCRIPTION</label>
        <textarea name="description" rows="3" class="w-full rounded-xl border-2 border-gray-200 px-4 py-3 focus:border-gold focus:outline-none"></textarea>
      </div>
      <div>
        <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">DUE DATE *</label>
        <input name="due_date" type="date" required min="<?php echo e(date('Y-m-d')); ?>" class="w-full min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
      </div>
      <button class="w-full min-h-[48px] rounded-xl bg-gold text-navy font-bold">📤 Post + Notify Parents</button>
    </form>
  </div>

  
  <div class="bg-white rounded-2xl p-6 shadow">
    <h2 class="font-extrabold text-navy mb-4">📋 Recent Posts</h2>
    <?php if($homework->count()): ?>
      <div class="space-y-3">
        <?php $__currentLoopData = $homework; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="p-3 rounded-xl bg-gray-50 border-l-4 border-navy">
            <div class="flex justify-between text-xs text-gray-500">
              <span><?php echo e($hw->class); ?> <?php echo e($hw->stream); ?> · <?php echo e($hw->subject); ?></span>
              <span>Due: <?php echo e($hw->due_date->format('d M')); ?></span>
            </div>
            <div class="font-semibold text-navy text-sm mt-1"><?php echo e($hw->title); ?></div>
            <?php if($hw->description): ?>
              <div class="text-xs text-gray-600 mt-1"><?php echo e(\Illuminate\Support\Str::limit($hw->description, 100)); ?></div>
            <?php endif; ?>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="mt-4"><?php echo e($homework->links()); ?></div>
    <?php else: ?>
      <div class="text-center py-8 text-gray-400 text-sm">
        <div class="text-3xl mb-2">📭</div>
        No homework posted yet.
      </div>
    <?php endif; ?>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/teacher/homework.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'News'); ?>
<?php $__env->startSection('content'); ?>
<div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-6">
  <div><h1 class="text-2xl md:text-3xl font-extrabold text-navy">News &amp; Updates</h1><p class="text-sm text-gray-500 mt-1"><?php echo e($news->total()); ?> posts</p></div>
  <a href="<?php echo e(route('principal.news.create')); ?>" class="px-4 py-2 rounded-xl bg-gold text-navy font-bold text-sm hover:scale-105 transition">+ New Post</a>
</div>
<?php if(session('success')): ?><div class="bg-green-50 border-l-4 border-green-600 p-4 rounded-lg mb-4"><div class="font-bold text-green-700">✅ <?php echo e(session('success')); ?></div></div><?php endif; ?>
<div class="bg-white rounded-2xl shadow overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500"><tr class="text-left"><th class="p-3">TITLE</th><th class="p-3">DATE</th><th class="p-3 text-center">STATUS</th><th class="p-3 text-right">ACTION</th></tr></thead>
    <tbody class="divide-y">
      <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="hover:bg-gray-50">
          <td class="p-3"><div class="font-semibold text-navy"><?php echo e($n->title); ?></div><div class="text-xs text-gray-500"><?php echo e(\Illuminate\Support\Str::limit($n->excerpt, 60)); ?></div></td>
          <td class="p-3 text-xs text-gray-500"><?php echo e($n->created_at->format('d M Y')); ?></td>
          <td class="p-3 text-center"><span class="px-2 py-1 rounded-full text-xs font-bold <?php echo e($n->published ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'); ?>"><?php echo e($n->published ? 'Published' : 'Draft'); ?></span></td>
          <td class="p-3 text-right whitespace-nowrap">
            <a href="/news/<?php echo e($n->slug); ?>" target="_blank" class="text-xs font-semibold text-navy hover:text-gold">View</a>
            <a href="<?php echo e(route('principal.news.edit', $n)); ?>" class="text-xs font-semibold text-navy hover:text-gold ml-2">Edit</a>
            <form method="POST" action="<?php echo e(route('principal.news.destroy', $n)); ?>" class="inline" onsubmit="return confirm('Delete?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="text-xs font-semibold text-red-600 hover:underline ml-2">Delete</button></form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="4" class="p-12 text-center text-gray-400 text-sm">No news yet</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<div class="mt-4"><?php echo e($news->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/principal/news/index.blade.php ENDPATH**/ ?>
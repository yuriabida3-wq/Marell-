<?php $__env->startSection('title', 'Parent Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<section class="bg-navy text-white py-10">
  <div class="max-w-6xl mx-auto px-4">
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
      <div>
        <div class="text-gold font-bold tracking-widest text-xs">PARENT PORTAL</div>
        <h1 class="text-2xl md:text-3xl font-extrabold mt-1">Welcome, <?php echo e($selected->parent_name); ?></h1>
        <div class="text-white/70 text-sm mt-1">📱 <?php echo e($phone); ?></div>
      </div>
      <form method="POST" action="<?php echo e(route('parent.logout')); ?>">
        <?php echo csrf_field(); ?>
        <button class="btn btn-outline text-sm !min-h-[42px]">Log Out</button>
      </form>
    </div>
  </div>
</section>

<section class="max-w-6xl mx-auto px-4 py-8">

  
  <?php if($children->count() > 1): ?>
    <div class="mb-6">
      <div class="text-xs text-gray-500 font-semibold tracking-widest mb-2">SWITCH CHILD</div>
      <div class="flex flex-wrap gap-2">
        <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(route('parent.dashboard', ['child' => $c->id])); ?>"
             class="px-4 py-2 rounded-xl text-sm font-semibold transition <?php echo e($c->id === $selected->id ? 'bg-navy text-white' : 'bg-gray-200 text-navy hover:bg-gray-300'); ?>">
            <?php echo e($c->name); ?> · <?php echo e($c->class); ?>

          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  <?php endif; ?>

  
  <div class="card p-6 mb-6" data-aos="fade-up">
    <div class="flex flex-col sm:flex-row sm:items-center gap-4">
      <div class="w-16 h-16 rounded-full bg-gold flex items-center justify-center font-bold text-navy text-2xl flex-shrink-0">
        <?php echo e(strtoupper(substr($selected->name, 0, 1))); ?>

      </div>
      <div class="flex-1">
        <div class="text-2xl font-extrabold text-navy"><?php echo e($selected->name); ?></div>
        <div class="text-sm text-gray-600"><?php echo e($selected->adm_no); ?> · <?php echo e($selected->class); ?> <?php echo e($selected->stream); ?></div>
      </div>
    </div>

    <div class="grid grid-cols-3 gap-3 mt-6">
      <div class="bg-gray-50 rounded-xl p-4 text-center">
        <div class="text-xs text-gray-500 tracking-widest">TOTAL FEE</div>
        <div class="text-lg md:text-xl font-bold text-navy mt-1">KES <?php echo e(number_format($selected->total_fee, 0)); ?></div>
      </div>
      <div class="bg-green-50 rounded-xl p-4 text-center">
        <div class="text-xs text-gray-500 tracking-widest">PAID</div>
        <div class="text-lg md:text-xl font-bold text-green-700 mt-1">KES <?php echo e(number_format($selected->paid_amount, 0)); ?></div>
      </div>
      <div class="bg-red-50 rounded-xl p-4 text-center">
        <div class="text-xs text-gray-500 tracking-widest">BALANCE</div>
        <div class="text-lg md:text-xl font-bold text-red-600 mt-1">KES <?php echo e(number_format($selected->balance, 0)); ?></div>
      </div>
    </div>

    
    <?php
      $pct = $selected->total_fee > 0 ? round(($selected->paid_amount / $selected->total_fee) * 100) : 0;
    ?>
    <div class="mt-6">
      <div class="flex justify-between text-xs font-semibold mb-2">
        <span class="text-gray-600">Fee Progress</span>
        <span class="text-navy"><?php echo e($pct); ?>% Paid</span>
      </div>
      <div class="w-full h-3 rounded-full bg-gray-200 overflow-hidden">
        <div class="h-full bg-gradient-to-r from-navy to-gold" style="width: <?php echo e($pct); ?>%"></div>
      </div>
    </div>

    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6">
      <a href="<?php echo e(route('pay')); ?>?adm=<?php echo e($selected->adm_no); ?>" class="btn btn-gold text-sm">💳 Pay Fees</a>
      <a href="#results" class="btn btn-navy text-sm">📊 View Results</a>
      <a href="#payments" class="btn bg-gray-200 text-navy text-sm">📄 Receipts</a>
      <a href="/contact" class="btn bg-gray-200 text-navy text-sm">📞 Support</a>
    </div>
  </div>

  <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

    
    <div id="results" class="card p-6" data-aos="fade-up">
      <div class="flex items-center justify-between mb-4">
        <h2 class="font-extrabold text-navy text-lg">📊 Recent Results</h2>
        <span class="text-xs text-gray-500"><?php echo e($results->count()); ?> subjects</span>
      </div>

      <?php if($results->count()): ?>
        <div class="overflow-x-auto">
          <table class="w-full text-sm">
            <thead class="bg-gray-100 text-navy">
              <tr><th class="p-2 text-left">Subject</th><th class="p-2 text-center">Marks</th><th class="p-2 text-center">Grade</th></tr>
            </thead>
            <tbody class="divide-y">
              <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="p-2 font-semibold"><?php echo e($r->subject); ?></td>
                  <td class="p-2 text-center font-bold"><?php echo e($r->marks); ?></td>
                  <td class="p-2 text-center">
                    <span class="inline-flex items-center justify-center min-w-[36px] h-7 rounded-full font-bold text-xs
                      <?php if(in_array($r->grade,['A','A-'])): ?> bg-green-100 text-green-700
                      <?php elseif(in_array($r->grade,['B+','B','B-'])): ?> bg-blue-100 text-blue-700
                      <?php elseif(in_array($r->grade,['C+','C','C-'])): ?> bg-yellow-100 text-yellow-700
                      <?php else: ?> bg-red-100 text-red-700 <?php endif; ?>"><?php echo e($r->grade); ?></span>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="text-center py-8 text-gray-500 text-sm">
          <div class="text-3xl mb-2">📭</div>
          No results published yet.
        </div>
      <?php endif; ?>
    </div>

    
    <div id="payments" class="card p-6" data-aos="fade-up" data-aos-delay="100">
      <div class="flex items-center justify-between mb-4">
        <h2 class="font-extrabold text-navy text-lg">📄 Recent Payments</h2>
        <span class="text-xs text-gray-500">Last 5</span>
      </div>

      <?php if($payments->count()): ?>
        <div class="space-y-3">
          <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex items-center justify-between p-3 rounded-xl bg-gray-50">
              <div>
                <div class="font-semibold text-navy text-sm">KES <?php echo e(number_format($p->amount, 2)); ?></div>
                <div class="text-xs text-gray-500"><?php echo e($p->created_at->format('d M Y')); ?> · <?php echo e($p->transaction_code ?: $p->method); ?></div>
              </div>
              <a href="<?php echo e(URL::signedRoute('pay.receipt', ['payment' => $p->id])); ?>" class="text-xs font-semibold text-navy hover:text-gold">📥 Receipt</a>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php else: ?>
        <div class="text-center py-8 text-gray-500 text-sm">
          <div class="text-3xl mb-2">💸</div>
          No payments yet.
        </div>
      <?php endif; ?>
    </div>

  </div>

  
  <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
    <div class="card p-4 text-center" data-aos="fade-up">
      <div class="text-2xl mb-1">📅</div>
      <div class="text-xs text-gray-500">Timetable</div>
      <div class="text-xs font-bold text-navy mt-1">Coming soon</div>
    </div>
    <div class="card p-4 text-center" data-aos="fade-up">
      <div class="text-2xl mb-1">📚</div>
      <div class="text-xs text-gray-500">Homework</div>
      <div class="text-xs font-bold text-navy mt-1">Coming soon</div>
    </div>
    <div class="card p-4 text-center" data-aos="fade-up">
      <div class="text-2xl mb-1">📢</div>
      <div class="text-xs text-gray-500">News &amp; Events</div>
      <div class="text-xs font-bold text-navy mt-1"><a href="/news" class="text-navy underline">View all</a></div>
    </div>
    <div class="card p-4 text-center" data-aos="fade-up">
      <div class="text-2xl mb-1">💰</div>
      <div class="text-xs text-gray-500">Fee Statement</div>
      <div class="text-xs font-bold text-navy mt-1">Coming soon</div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/public/parent-dashboard.blade.php ENDPATH**/ ?>
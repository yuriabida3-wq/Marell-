<?php $__env->startSection('title', 'Exams'); ?>
<?php $__env->startSection('content'); ?>

<div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-6">
  <div>
    <h1 class="text-2xl md:text-3xl font-extrabold text-navy">Exams</h1>
    <p class="text-sm text-gray-500 mt-1"><?php echo e($exams->total()); ?> total exams</p>
  </div>
  <a href="<?php echo e(route('dos.exams.create')); ?>" class="px-4 py-2 rounded-xl bg-gold text-navy font-bold text-sm hover:scale-105 transition">+ Create Exam</a>
</div>

<?php if(session('success')): ?>
  <div class="bg-green-50 border-l-4 border-green-600 p-4 rounded-lg mb-4"><div class="font-bold text-green-700">✅ <?php echo e(session('success')); ?></div></div>
<?php endif; ?>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
  <?php $__empty_1 = true; $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="bg-white rounded-2xl p-5 shadow hover:shadow-lg transition">
      <div class="flex items-start justify-between mb-3">
        <div>
          <div class="font-extrabold text-navy text-lg"><?php echo e($exam->name); ?></div>
          <div class="text-xs text-gray-500"><?php echo e($exam->term); ?> · <?php echo e($exam->year); ?></div>
        </div>
        <?php
          $cls = match($exam->status) {
            'draft'     => 'bg-gray-100 text-gray-700',
            'open'      => 'bg-blue-100 text-blue-700',
            'closed'    => 'bg-yellow-100 text-yellow-700',
            'published' => 'bg-green-100 text-green-700',
          };
        ?>
        <span class="px-2 py-1 rounded-full text-xs font-bold <?php echo e($cls); ?>"><?php echo e(ucfirst($exam->status)); ?></span>
      </div>

      <div class="text-sm text-gray-600 mb-4">
        <div class="flex justify-between"><span>Marks entries:</span><span class="font-bold text-navy"><?php echo e($exam->results_count); ?></span></div>
      </div>

      <div class="flex gap-2">
        <a href="<?php echo e(route('dos.exams.show', $exam)); ?>" class="flex-1 text-center px-3 py-2 rounded-xl bg-navy text-white text-xs font-semibold hover:scale-105 transition">Manage</a>
        <a href="<?php echo e(route('dos.marks', ['exam_id' => $exam->id])); ?>" class="flex-1 text-center px-3 py-2 rounded-xl bg-gold text-navy text-xs font-semibold hover:scale-105 transition">Enter Marks</a>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="md:col-span-2 lg:col-span-3 text-center py-16 text-gray-400">
      <div class="text-4xl mb-2">📝</div>
      No exams yet. Click <strong>+ Create Exam</strong> to start.
    </div>
  <?php endif; ?>
</div>

<div class="mt-4"><?php echo e($exams->links()); ?></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dos', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/dos/exams/index.blade.php ENDPATH**/ ?>
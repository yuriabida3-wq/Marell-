<?php $__env->startSection('title', $post->title); ?>
<?php $__env->startSection('content'); ?>
<section class="bg-navy text-white py-12 md:py-16">
  <div class="max-w-4xl mx-auto px-4 text-center" data-aos="fade-up">
    <div class="text-gold font-bold tracking-widest text-xs"><?php echo e($post->created_at->format('d M Y')); ?></div>
    <h1 class="text-2xl md:text-4xl font-extrabold mt-2"><?php echo e($post->title); ?></h1>
  </div>
</section>
<article class="max-w-3xl mx-auto px-4 py-12">
  <?php if($post->image): ?>
    <img src="<?php echo e($post->image); ?>" class="w-full h-72 object-cover rounded-2xl shadow-xl mb-8">
  <?php endif; ?>
  <div class="prose max-w-none text-gray-700 leading-relaxed whitespace-pre-wrap"><?php echo e($post->body); ?></div>
  <div class="mt-12 pt-8 border-t">
    <a href="/news" class="text-navy font-semibold hover:text-gold">← Back to news</a>
  </div>

  <?php if($related->count()): ?>
    <div class="mt-12">
      <h2 class="font-extrabold text-navy text-xl mb-4">Related</h2>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="/news/<?php echo e($r->slug); ?>" class="card p-4 hover:shadow-lg transition">
            <div class="text-xs text-gold font-semibold"><?php echo e($r->created_at->format('d M Y')); ?></div>
            <div class="font-bold text-navy mt-1"><?php echo e($r->title); ?></div>
          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  <?php endif; ?>
</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/public/news-show.blade.php ENDPATH**/ ?>
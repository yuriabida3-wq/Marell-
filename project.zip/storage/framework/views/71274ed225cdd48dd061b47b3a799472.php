<?php $__env->startSection('title', 'Messages'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-6 flex items-center justify-between">
  <div><h1 class="text-2xl md:text-3xl font-extrabold text-navy">Contact Messages</h1><p class="text-sm text-gray-500 mt-1"><?php echo e($unhandled); ?> unread</p></div>
  <a href="?unhandled=1" class="px-4 py-2 rounded-xl bg-navy text-white text-sm font-semibold">Show Unread Only</a>
</div>
<div class="bg-white rounded-2xl shadow overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500"><tr class="text-left"><th class="p-3">DATE</th><th class="p-3">NAME</th><th class="p-3">SUBJECT</th><th class="p-3">PHONE</th><th class="p-3 text-center">STATUS</th><th class="p-3 text-right">ACTION</th></tr></thead>
    <tbody class="divide-y">
      <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="hover:bg-gray-50 <?php echo e(!$m->handled ? 'bg-blue-50' : ''); ?>">
          <td class="p-3 text-xs text-gray-500"><?php echo e($m->created_at->format('d M H:i')); ?></td>
          <td class="p-3 font-semibold text-navy"><?php echo e($m->name); ?></td>
          <td class="p-3 text-gray-600"><?php echo e(\Illuminate\Support\Str::limit($m->subject ?: $m->message, 50)); ?></td>
          <td class="p-3 text-gray-600 font-mono text-xs"><?php echo e($m->phone ?: '—'); ?></td>
          <td class="p-3 text-center"><?php if($m->handled): ?><span class="text-xs text-green-700 font-bold">✓ Handled</span><?php else: ?><span class="text-xs text-blue-700 font-bold">● New</span><?php endif; ?></td>
          <td class="p-3 text-right"><a href="<?php echo e(route('principal.contacts.show', $m)); ?>" class="text-xs font-semibold text-navy hover:text-gold">View</a></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6" class="p-12 text-center text-gray-400">No messages</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<div class="mt-4"><?php echo e($messages->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/principal/contacts/index.blade.php ENDPATH**/ ?>
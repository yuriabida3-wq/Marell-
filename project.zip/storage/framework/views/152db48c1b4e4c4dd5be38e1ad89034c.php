<?php $__env->startSection('title', 'Timetable by Teacher'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6">
  <a href="<?php echo e(route('dos.timetable.index')); ?>" class="text-xs text-gray-500 hover:text-navy">← Timetable</a>
  <h1 class="text-2xl md:text-3xl font-extrabold text-navy mt-1">Timetable by Teacher</h1>
</div>

<div class="bg-white rounded-2xl p-6 shadow mb-4">
  <form method="GET" class="flex flex-col sm:flex-row gap-3">
    <select name="teacher_id" required class="flex-1 min-h-[48px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none">
      <option value="">-- Select Teacher --</option>
      <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($t->id); ?>" <?php if($teacher && $teacher->id === $t->id): echo 'selected'; endif; ?>><?php echo e($t->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn btn-navy">🔍 Show Timetable</button>
  </form>
</div>

<?php if($teacher): ?>
  <div class="bg-white rounded-2xl shadow overflow-hidden">
    <div class="p-4 border-b bg-navy text-white">
      <div class="font-extrabold"><?php echo e($teacher->name); ?>'s Weekly Schedule</div>
    </div>
    <div class="overflow-x-auto">
      <table class="w-full text-xs">
        <thead class="bg-gray-50">
          <tr>
            <th class="p-2 text-left w-16">PERIOD</th>
            <?php $__currentLoopData = ['Mon','Tue','Wed','Thu','Fri']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <th class="p-2 text-center"><?php echo e($d); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
        </thead>
        <tbody class="divide-y">
          <?php for($p = 1; $p <= 8; $p++): ?>
            <tr class="<?php echo e($p % 2 ? 'bg-white' : 'bg-gray-50'); ?>">
              <td class="p-2 font-bold text-navy">P<?php echo e($p); ?></td>
              <?php $__currentLoopData = ['Mon','Tue','Wed','Thu','Fri']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $slot = $grid[$d][$p] ?? null; ?>
                <td class="p-1.5 text-center align-top">
                  <?php if($slot): ?>
                    <div class="rounded-lg bg-gold/10 border border-gold/40 p-1.5">
                      <div class="font-bold text-navy text-[11px]"><?php echo e($slot->subject); ?></div>
                      <div class="text-[9px] text-gray-600"><?php echo e($slot->class); ?> <?php echo e($slot->stream); ?></div>
                    </div>
                  <?php else: ?>
                    <span class="text-gray-300">—</span>
                  <?php endif; ?>
                </td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
          <?php endfor; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php else: ?>
  <div class="text-center py-12 text-gray-400">
    <div class="text-4xl mb-2">👨‍🏫</div>
    Select a teacher to view their weekly schedule.
  </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dos', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/dos/timetable/teacher.blade.php ENDPATH**/ ?>
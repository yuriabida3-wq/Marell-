<?php $__env->startSection('title', $contact->name); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-6"><a href="<?php echo e(route('principal.contacts.index')); ?>" class="text-xs text-gray-500">← Messages</a><h1 class="text-2xl md:text-3xl font-extrabold text-navy mt-1"><?php echo e($contact->subject ?: 'Message from ' . $contact->name); ?></h1></div>
<div class="bg-white rounded-2xl p-6 shadow max-w-3xl">
  <table class="w-full text-sm mb-4">
    <tr class="border-b"><td class="py-2 text-gray-500">From</td><td class="py-2 text-right font-semibold"><?php echo e($contact->name); ?></td></tr>
    <tr class="border-b"><td class="py-2 text-gray-500">Email</td><td class="py-2 text-right"><?php echo e($contact->email ?: '—'); ?></td></tr>
    <tr class="border-b"><td class="py-2 text-gray-500">Phone</td><td class="py-2 text-right font-mono"><?php echo e($contact->phone ?: '—'); ?></td></tr>
    <tr><td class="py-2 text-gray-500">Date</td><td class="py-2 text-right text-xs"><?php echo e($contact->created_at->format('d M Y H:i')); ?></td></tr>
  </table>
  <div class="bg-gray-50 rounded-xl p-4 text-sm whitespace-pre-wrap"><?php echo e($contact->message); ?></div>
  <div class="mt-4 flex flex-wrap gap-2">
    <?php if($contact->email): ?><a href="mailto:<?php echo e($contact->email); ?>" class="px-4 py-2 rounded-xl bg-navy text-white text-sm font-semibold">✉️ Reply Email</a><?php endif; ?>
    <?php if($contact->phone): ?><a href="tel:<?php echo e($contact->phone); ?>" class="px-4 py-2 rounded-xl bg-green-600 text-white text-sm font-semibold">📞 Call</a><?php endif; ?>
    <form method="POST" action="<?php echo e(route('principal.contacts.toggle', $contact)); ?>" class="contents"><?php echo csrf_field(); ?><button class="px-4 py-2 rounded-xl bg-gray-200 text-navy text-sm font-semibold"><?php echo e($contact->handled ? 'Mark Unread' : 'Mark Handled'); ?></button></form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/principal/contacts/show.blade.php ENDPATH**/ ?>
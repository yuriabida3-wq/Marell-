<?php $__env->startSection('title', 'Record Payment'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6">
  <h1 class="text-2xl md:text-3xl font-extrabold text-navy">Record Payment</h1>
  <p class="text-sm text-gray-500 mt-1">Search a student to record cash/bank payment.</p>
</div>

<?php if(session('success')): ?>
  <div class="bg-green-50 border-l-4 border-green-600 p-4 rounded-lg mb-4"><div class="font-bold text-green-700">✅ <?php echo e(session('success')); ?></div></div>
<?php endif; ?>
<?php if(session('error')): ?>
  <div class="bg-red-50 border-l-4 border-red-600 p-4 rounded-lg mb-4"><div class="font-bold text-red-700"><?php echo e(session('error')); ?></div></div>
<?php endif; ?>

<div class="bg-white rounded-2xl p-4 shadow mb-4">
  <form method="GET" action="<?php echo e(route('bursar.record')); ?>" class="flex gap-2">
    <input name="adm" value="<?php echo e(request('adm')); ?>" placeholder="ADM number..." required autofocus
           class="flex-1 min-h-[52px] rounded-xl border-2 border-gray-200 px-4 text-lg focus:border-gold focus:outline-none">
    <button class="min-h-[52px] px-6 rounded-xl bg-navy text-white font-bold">🔍</button>
  </form>
</div>

<?php if($student): ?>
  <div class="bg-white rounded-2xl p-5 shadow mb-4">
    <div class="font-bold text-navy text-lg"><?php echo e($student->name); ?></div>
    <div class="text-xs text-gray-500"><?php echo e($student->adm_no); ?> · <?php echo e($student->class); ?></div>
    <div class="grid grid-cols-3 gap-2 mt-3 text-center">
      <div class="bg-gray-50 rounded-xl p-2"><div class="text-xs text-gray-500">Total</div><div class="font-bold text-navy text-sm">KES <?php echo e(number_format($student->total_fee, 0)); ?></div></div>
      <div class="bg-green-50 rounded-xl p-2"><div class="text-xs text-gray-500">Paid</div><div class="font-bold text-green-700 text-sm">KES <?php echo e(number_format($student->paid_amount, 0)); ?></div></div>
      <div class="bg-red-50 rounded-xl p-2"><div class="text-xs text-gray-500">Balance</div><div class="font-bold text-red-600 text-sm">KES <?php echo e(number_format($student->balance, 0)); ?></div></div>
    </div>
  </div>

  <div class="bg-white rounded-2xl p-6 shadow">
    <form method="POST" action="<?php echo e(route('bursar.record.store')); ?>" class="space-y-3">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="adm" value="<?php echo e($student->adm_no); ?>">
      <div>
        <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">AMOUNT *</label>
        <input name="amount" type="number" min="1" value="<?php echo e((int) $student->balance); ?>" required class="w-full min-h-[52px] rounded-xl border-2 border-gray-200 px-4 text-lg focus:border-gold focus:outline-none">
      </div>
      <div>
        <label class="block text-xs font-semibold text-navy mb-2 tracking-widest">METHOD *</label>
        <select name="method" class="w-full min-h-[52px] rounded-xl border-2 border-gray-200 px-4 focus:border-gold focus:outline-none"><option>Cash</option><option>Bank</option><option>M-Pesa</option></select>
      </div>
      <label class="flex items-center gap-2 text-sm text-gray-700">
        <input type="checkbox" name="send_sms" value="1" class="w-5 h-5" checked>
        Send SMS receipt to parent
      </label>
      <button class="w-full min-h-[52px] rounded-xl bg-gold text-navy font-bold">💾 Record Payment</button>
    </form>
  </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bursar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/bursar/record.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Finance'); ?>
<?php $__env->startSection('content'); ?>

<div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-6">
  <div>
    <h1 class="text-2xl md:text-3xl font-extrabold text-navy">Finance</h1>
    <p class="text-sm text-gray-500 mt-1"><?php echo e($countSum); ?> payments · Completed: KES <?php echo e(number_format($totalSum, 0)); ?></p>
  </div>
  <div class="flex flex-wrap gap-2">
    <a href="<?php echo e(route('principal.finance.record')); ?>" class="px-4 py-2 rounded-xl bg-gold text-navy font-bold text-sm hover:scale-105 transition">+ Record Payment</a>
    <a href="<?php echo e(route('principal.finance.daily')); ?>" class="px-4 py-2 rounded-xl bg-navy text-white text-sm font-semibold hover:scale-105 transition">📅 Daily Report</a>
    <a href="<?php echo e(route('principal.finance.export')); ?>?<?php echo e(http_build_query(request()->only(['q','method','status','from','to']))); ?>"
       class="px-4 py-2 rounded-xl bg-green-600 text-white text-sm font-semibold hover:scale-105 transition">📊 Export</a>
  </div>
</div>


<div class="bg-white rounded-2xl p-4 shadow mb-4">
  <form method="GET" class="grid grid-cols-1 md:grid-cols-5 gap-3">
    <input name="q" value="<?php echo e($q); ?>" placeholder="🔍 Search txn, receipt, name, ADM..."
           class="md:col-span-2 min-h-[42px] rounded-xl border-2 border-gray-200 px-4 text-sm focus:border-gold focus:outline-none">

    <select name="method" class="min-h-[42px] rounded-xl border-2 border-gray-200 px-4 text-sm focus:border-gold focus:outline-none">
      <option value="">All Methods</option>
      <option value="M-Pesa" <?php if($method === 'M-Pesa'): echo 'selected'; endif; ?>>M-Pesa</option>
      <option value="Cash"   <?php if($method === 'Cash'): echo 'selected'; endif; ?>>Cash</option>
      <option value="Bank"   <?php if($method === 'Bank'): echo 'selected'; endif; ?>>Bank</option>
    </select>

    <select name="status" class="min-h-[42px] rounded-xl border-2 border-gray-200 px-4 text-sm focus:border-gold focus:outline-none">
      <option value="">All Statuses</option>
      <option value="completed" <?php if($status === 'completed'): echo 'selected'; endif; ?>>Completed</option>
      <option value="pending"   <?php if($status === 'pending'): echo 'selected'; endif; ?>>Pending</option>
      <option value="failed"    <?php if($status === 'failed'): echo 'selected'; endif; ?>>Failed</option>
    </select>

    <div class="grid grid-cols-2 gap-2">
      <input type="date" name="from" value="<?php echo e($from); ?>" class="min-h-[42px] rounded-xl border-2 border-gray-200 px-3 text-xs focus:border-gold focus:outline-none">
      <input type="date" name="to"   value="<?php echo e($to); ?>"   class="min-h-[42px] rounded-xl border-2 border-gray-200 px-3 text-xs focus:border-gold focus:outline-none">
    </div>

    <button class="md:col-span-5 min-h-[42px] rounded-xl bg-navy text-white font-semibold text-sm hover:scale-[1.02] transition">Apply Filters</button>
  </form>
</div>


<div class="bg-white rounded-2xl shadow overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500">
        <tr class="text-left">
          <th class="p-3">DATE</th>
          <th class="p-3">RECEIPT</th>
          <th class="p-3">STUDENT</th>
          <th class="p-3">METHOD</th>
          <th class="p-3">TXN CODE</th>
          <th class="p-3 text-right">AMOUNT</th>
          <th class="p-3 text-center">STATUS</th>
          <th class="p-3 text-right">RECEIPT</th>
        </tr>
      </thead>
      <tbody class="divide-y">
        <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="hover:bg-gray-50">
            <td class="p-3 text-gray-500 text-xs"><?php echo e($p->created_at->format('d M Y H:i')); ?></td>
            <td class="p-3 font-mono text-xs text-navy"><?php echo e($p->receipt_no ?: '—'); ?></td>
            <td class="p-3">
              <div class="font-semibold text-navy"><?php echo e($p->student->name ?? '—'); ?></div>
              <div class="text-xs text-gray-500"><?php echo e($p->student->adm_no ?? ''); ?> · <?php echo e($p->student->class ?? ''); ?></div>
            </td>
            <td class="p-3"><?php echo e($p->method); ?></td>
            <td class="p-3 font-mono text-xs"><?php echo e($p->transaction_code ?: '—'); ?></td>
            <td class="p-3 text-right font-bold text-navy">KES <?php echo e(number_format($p->amount, 0)); ?></td>
            <td class="p-3 text-center">
              <?php
                $cls = match($p->status) {
                  'completed' => 'bg-green-100 text-green-700',
                  'pending'   => 'bg-yellow-100 text-yellow-700',
                  default     => 'bg-red-100 text-red-700',
                };
              ?>
              <span class="px-2 py-1 rounded-full text-xs font-bold <?php echo e($cls); ?>"><?php echo e(ucfirst($p->status)); ?></span>
            </td>
            <td class="p-3 text-right">
              <?php if($p->status === 'completed'): ?>
                <a href="<?php echo e(URL::signedRoute('pay.receipt', ['payment' => $p->id])); ?>" class="text-xs font-semibold text-navy hover:text-gold">📄 PDF</a>
              <?php else: ?>
                —
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="8" class="p-12 text-center text-gray-400 text-sm">No payments</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="mt-4"><?php echo e($payments->links()); ?></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/principal/finance/index.blade.php ENDPATH**/ ?>
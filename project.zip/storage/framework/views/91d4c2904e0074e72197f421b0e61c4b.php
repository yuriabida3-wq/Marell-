<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6">
  <h1 class="text-2xl md:text-3xl font-extrabold text-navy">Bursar Dashboard</h1>
  <p class="text-sm text-gray-500 mt-1">Welcome back, <?php echo e(auth()->user()->name); ?></p>
</div>

<div class="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
  <div class="bg-gradient-to-br from-navy to-[#082f6f] rounded-2xl p-5 text-white shadow-lg">
    <div class="text-[10px] tracking-widest font-bold text-gold">TODAY</div>
    <div class="text-2xl md:text-3xl font-extrabold mt-2">KES <?php echo e(number_format($todayTotal, 0)); ?></div>
    <div class="text-xs text-white/70 mt-1"><?php echo e($todayCount); ?> payments</div>
  </div>
  <div class="bg-white rounded-2xl p-5 shadow">
    <div class="text-[10px] tracking-widest font-bold text-red-600">DEFAULTERS</div>
    <div class="text-2xl md:text-3xl font-extrabold text-red-600 mt-2"><?php echo e($defaulters); ?></div>
  </div>
  <div class="bg-white rounded-2xl p-5 shadow col-span-2">
    <div class="text-[10px] tracking-widest font-bold text-gold">TOTAL OUTSTANDING</div>
    <div class="text-2xl md:text-3xl font-extrabold text-navy mt-2">KES <?php echo e(number_format($totalOutstanding, 0)); ?></div>
  </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
  <div class="bg-white rounded-2xl p-6 shadow">
    <h2 class="font-extrabold text-navy mb-4">⚡ Quick Actions</h2>
    <div class="grid grid-cols-2 gap-3">
      <a href="/bursar/students" class="quick-btn bg-navy text-white text-sm">🔍 Find Student</a>
      <a href="/bursar/record" class="quick-btn bg-gold text-navy text-sm">➕ Record</a>
      <a href="/bursar/balances" class="quick-btn bg-gray-100 text-navy text-sm">📊 Balances</a>
      <a href="/bursar/daily" class="quick-btn bg-gray-100 text-navy text-sm">📅 Daily</a>
    </div>
  </div>

  <div class="bg-white rounded-2xl p-6 shadow">
    <div class="flex items-center justify-between mb-4">
      <h2 class="font-extrabold text-navy">💳 Recent</h2>
      <a href="/bursar/payments" class="text-xs text-navy hover:text-gold font-semibold">View all →</a>
    </div>
    <?php if($recent->count()): ?>
      <div class="space-y-2">
        <?php $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="flex items-center justify-between p-2 rounded-xl bg-gray-50">
            <div>
              <div class="text-sm font-semibold text-navy"><?php echo e($p->student->name ?? '—'); ?></div>
              <div class="text-xs text-gray-500"><?php echo e($p->receipt_no); ?> · <?php echo e($p->created_at->format('d M H:i')); ?></div>
            </div>
            <div class="text-sm font-bold text-green-700">KES <?php echo e(number_format($p->amount, 0)); ?></div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php else: ?>
      <p class="text-sm text-gray-400 text-center py-6">No payments yet</p>
    <?php endif; ?>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bursar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/JENGA_WEB/projects/marell/resources/views/bursar/dashboard.blade.php ENDPATH**/ ?>